<template>
    <svg
  width="16"
  height="16"
  viewBox="0 0 16 16"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  preserveAspectRatio="xMidYMid meet"
    >
  <path
    d="M6.83161 14.5437L1.45643 9.16848C0.84802 8.56008 0.84802 7.43986 1.45643 6.83145L6.83161 1.45628C7.44001 0.847868 8.56023 0.847868 9.16864 1.45628L14.5438 6.83145C15.1522 7.43986 15.1522 8.56008 14.5438 9.16848L9.16864 14.5437C8.56023 15.1521 7.44001 15.1521 6.83161 14.5437V14.5437Z"
    stroke="#6366F1"
    stroke-width="1.66667"
    stroke-linecap="round"
    stroke-linejoin="round"
  ></path>
    </svg>
</template>