<template>
    <svg
      width="21"
      height="20"
      viewBox="0 0 21 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="flex-grow-0 flex-shrink-0 w-5 h-5 relative"
      preserveAspectRatio="xMidYMid meet">
      <path
        d="M3.83333 10H17.1667C17.3877 10 17.5996 10.0878 17.7559 10.2441C17.9122 10.4004 18 10.6123 18 10.8333V13.3333C18 14.2174 17.6488 15.0652 17.0237 15.6904C16.3986 16.3155 15.5507 16.6667 14.6667 16.6667H6.33333C5.44928 16.6667 4.60143 16.3155 3.97631 15.6904C3.35119 15.0652 3 14.2174 3 13.3333V10.8333C3 10.6123 3.0878 10.4004 3.24408 10.2441C3.40036 10.0878 3.61232 10 3.83333 10V10Z"
        stroke="#6366F1"
        stroke-width="1.66667"
        stroke-linecap="round"
        stroke-linejoin="round"
      ></path>
      <path
        d="M5.5 10V4.16667C5.5 3.72464 5.67559 3.30072 5.98816 2.98816C6.30072 2.67559 6.72464 2.5 7.16667 2.5H9.66667V4.375"
        stroke="#6366F1"
        stroke-width="1.66667"
        stroke-linecap="round"
        stroke-linejoin="round"
      ></path>
      <path
        d="M3.83337 17.5L4.66671 16.25"
        stroke="#6366F1"
        stroke-width="1.66667"
        stroke-linecap="round"
        stroke-linejoin="round"
      ></path>
      <path
        d="M17.1667 17.5L16.3334 16.25"
        stroke="#6366F1"
        stroke-width="1.66667"
        stroke-linecap="round"
        stroke-linejoin="round"
      ></path>
    </svg>
</template>