<template>
  <section>
    <h1 class="text-2xl">
      Bonjour<code class="font-mono text-base">/src/pages/index.vue</code>
    </h1>
  </section>
</template>