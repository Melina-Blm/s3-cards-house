<template>
  <section>
    <h1 class="text-2xl text-center">
      Exercice de TP & TD (Intégration Formulaire) <br> Mélina Bouchelleghem TDB
    </h1>
  </section>
</template>